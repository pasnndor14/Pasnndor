// ضع رابط مشروع Supabase والمفتاح العام (anon / publishable) هنا.
// لا تضع service_role أو أي مفتاح سري داخل ملفات الموقع.
const SUPABASE_URL = "ضع_رابط_مشروعك_هنا";
const SUPABASE_ANON_KEY = "ضع_المفتاح_العام_هنا";

const grid = document.getElementById("products-grid");
const statusBox = document.getElementById("status");
const countBox = document.getElementById("product-count");
document.getElementById("year").textContent = new Date().getFullYear();

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  }[char]));
}

function renderProducts(products) {
  countBox.textContent = `${products.length} منتجات`;
  if (!products.length) {
    statusBox.textContent = "قاعدة البيانات متصلة، لكن لا توجد منتجات مفعّلة بعد. أضف منتجاتك إلى جدول products.";
    return;
  }
  statusBox.textContent = "تصفح المنتجات المتاحة في Pasnndor.";
  grid.innerHTML = products.map(product => `
    <article class="product-card">
      ${product.image_url
        ? `<div class="product-image" style="background-image:linear-gradient(#0003,#0006),url('${escapeHtml(product.image_url)}');background-size:cover;background-position:center"></div>`
        : `<div class="product-image">P.</div>`}
      <div class="product-info">
        <span class="category">${escapeHtml(product.category || "منتج رقمي")}</span>
        <h3>${escapeHtml(product.name)}</h3>
        <p>${escapeHtml(product.description || "")}</p>
        <div class="price">${Number(product.price).toLocaleString("en-US")} <small>ريال</small></div>
      </div>
    </article>`).join("");
}

async function loadProducts() {
  if (SUPABASE_URL.includes("ضع_") || SUPABASE_ANON_KEY.includes("ضع_")) {
    statusBox.textContent = "المتجر جاهز مبدئياً. الخطوة التالية: إضافة رابط Supabase والمفتاح العام لعرض المنتجات الحقيقية.";
    countBox.textContent = "بانتظار الربط";
    return;
  }
  try {
    const client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    const { data, error } = await client
      .from("products")
      .select("id,name,category,description,price,image_url,active")
      .eq("active", true)
      .order("created_at", { ascending: false });
    if (error) throw error;
    renderProducts(data || []);
  } catch (error) {
    console.error(error);
    countBox.textContent = "تعذر التحميل";
    statusBox.textContent = "تعذر تحميل المنتجات. تحقق من رابط Supabase والمفتاح العام وسياسات القراءة (RLS).";
  }
}
loadProducts();
